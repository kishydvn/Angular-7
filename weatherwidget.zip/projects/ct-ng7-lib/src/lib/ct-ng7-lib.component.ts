import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cnl-ct-ng7-lib',
  template: `
    <p>
      Custom library loads successfully!
    </p>
  `,
  styles: []
})
export class CtNg7LibComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
