import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cnl-libsample',
  templateUrl: './libsample.component.html',
  styleUrls: ['./libsample.component.css']
})
export class LibsampleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
