import { NgModule,ModuleWithProviders } from '@angular/core';
import { CtNg7LibComponent } from './ct-ng7-lib.component';
import { LibsampleComponent } from './libsample/libsample.component';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { CtNg7LibService } from './ct-ng7-lib.service';


@NgModule({
  declarations: [CtNg7LibComponent, LibsampleComponent],
  imports: [HttpClientModule, CommonModule
  ],
  exports: [CtNg7LibComponent, LibsampleComponent]
})
export class CtNg7LibModule {

    static forRoot() : ModuleWithProviders{
      return {
        ngModule: CtNg7LibModule,
        providers: [CtNg7LibService]
      }

    }
 }
