import { NgModule } from '@angular/core';
import { CtNg7LibComponent } from './ct-ng7-lib.component';
import { LibsampleComponent } from './libsample/libsample.component';

@NgModule({
  declarations: [CtNg7LibComponent, LibsampleComponent],
  imports: [
  ],
  exports: [CtNg7LibComponent, LibsampleComponent]
})
export class CtNg7LibModule { }
