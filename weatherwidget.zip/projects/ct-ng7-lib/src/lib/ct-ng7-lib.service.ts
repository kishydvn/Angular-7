import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CtNg7LibService {

  constructor() { }
}
