import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { User } from './user.model';

@Injectable({
  providedIn: 'root'
})
export class CtNg7LibService {
  apiurl = "http://jsonplaceholder.typicode.com/users";
  constructor(private _http:HttpClient) { }
  //http://jsonplaceholder.typicode.com/users
  //http://dummy.restapiexample.com/api/v1/employees
  //https://www.youtube.com/watch?v=yAT2HHusDDk
  //https://www.youtube.com/watch?v=p2Bvtv5PUJ0
  //https://www.youtube.com/watch?v=SBSnsNHQYo4
  //https://www.youtube.com/watch?v=vK22JIwWZPQ
  getUsers(){
    return this._http.get<User[]>(this.apiurl);
  }
}
