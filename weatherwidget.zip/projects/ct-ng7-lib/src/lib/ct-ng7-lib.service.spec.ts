import { TestBed } from '@angular/core/testing';

import { CtNg7LibService } from './ct-ng7-lib.service';

describe('CtNg7LibService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CtNg7LibService = TestBed.get(CtNg7LibService);
    expect(service).toBeTruthy();
  });
});
