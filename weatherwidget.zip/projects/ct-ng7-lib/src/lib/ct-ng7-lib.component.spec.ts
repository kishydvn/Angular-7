import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CtNg7LibComponent } from './ct-ng7-lib.component';

describe('CtNg7LibComponent', () => {
  let component: CtNg7LibComponent;
  let fixture: ComponentFixture<CtNg7LibComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CtNg7LibComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CtNg7LibComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
