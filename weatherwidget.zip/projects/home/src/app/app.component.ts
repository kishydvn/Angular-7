import { Component, OnInit } from '@angular/core';
//import { CtNg7LibService } from 'ct-ng7-lib/lib/ct-ng7-lib.service'
//import { User } from 'projects/ct-ng7-lib/src/lib/user.model';
import { CtNg7LibService } from 'ct-ng7-lib';
import { User } from 'ct-ng7-lib/public_api';

@Component({
  selector: 'home-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'home';
  users$: User[];

  constructor(private libService:CtNg7LibService){

  }

  ngOnInit(){
    return this.libService.getUsers().subscribe(data => this.users$ = data);
  }
}
