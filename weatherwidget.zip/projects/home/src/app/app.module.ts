import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { CtNg7LibModule } from 'ct-ng7-lib';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CtNg7LibModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
